# VDC_API
> VDC is my simple python project! The goal of this project is to create a nomial converter that can convert even decimals to n nomial form.


My product is close to a calculator. Even though the input is in a form of formula(e.x. 10*8+1/8), it will calculate it and convert it to n- nomial. Be creful though... The n of the n nomial should be a positive integer bigger than 1. This game was made to test my basic python abilities, and application skills. If possible, please give me a feedback about this converter so that I can improve furtherly in the future. This is a Pv(Prototype version), and it is prone to lots of errors! Please understand!

For the converter, you will need several things. First of all, you are required to download python and the file VersatileDeciConverter.py(if n < 64). If the n is larger than 64, you will be required to download the VersatileDeciConverterMT64.py. Each of the digits inside the brackets represent the digit on that place. Unauthorized spread of this product is strictly prohibited! Please do not lie to yourself. Also, email me if you want any authorization for my product!

![](header.png)

## Installation

OS X & Linux & Windows:

```sh
VersatileDeciConverter.py
```

## further explanation

My product is a converter, so the purpose is to be used as mathematical calculation with my product. The product is as convinient that it even converts float into n nomial. This may yet be prone to errors. Today is 06th of July of 2021 12:00 AM!
(skkim1733@gmail.com)

_For more examples and usage, please refer to the [Wiki][wiki]._

## Plan for further developement

No plans yet! But please email me for further development!


## update History

* v1
    * release v1 requires to be launched by python

## Meta

Seunghyeon Kim – [@YourInsta](red_seunghk_1206) – Skkim1733@gmail.com

Distributed under the XYZ license. See ``LICENSE`` for more information.

[https://github.com/yourname/github-link](https://github.com/dbader/)
